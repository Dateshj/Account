﻿namespace WebApplication1.Areas.AccountCategory.Data
{
    public class fake
    {
    }
}
