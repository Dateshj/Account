﻿namespace WebApplication1.Areas.AccountCategory.Models
{
    public class AccountCategoryModel
    {
    }
}
